 /******************************************************************************
 *
 * Module: LCD
 *
 * File Name: lcd.c
 *
 * Description: Driver for LCD 8 bit mode
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/
#include "lcd.h"
#include "gpio.h"
#include "util/delay.h"
#include <stdlib.h>

/*******************************************************************************
� Description
       -The Function to initialise LCD as written in the Data Sheet
� Inputs: None
� Return: None
 *******************************************************************************/
void LCD_init(void){
	GPIO_setupPinDirection(LCD_POWER_PORT, LCD_RS, PIN_OUTPUT);
	GPIO_setupPinDirection(LCD_POWER_PORT, LCD_RW, PIN_OUTPUT);
	GPIO_setupPinDirection(LCD_POWER_PORT, LCD_ENABLE, PIN_OUTPUT);
	GPIO_setupPortDirection(LCD_DATA_PORT, PORT_OUTPUT);
	LCD_sendCommand(CMD_2LINES_5x8_MATRIX);
	LCD_sendCommand(CMD_DISPON_CURSOROOFF);
	LCD_sendCommand(CMD_CLEAR_DISPLAY);
}

/*******************************************************************************
� Description
       -The Function is responsible to make RS pin to be 0 to send the wanted
       	command
� Inputs:
		-command: This is an 8 bit variable holding the binary of the required
				  command to be sent
� Return: None
 *******************************************************************************/
void LCD_sendCommand(uint8 a_command){
	GPIO_writePin(LCD_POWER_PORT, LCD_RS, LOGIC_LOW);
	GPIO_writePin(LCD_POWER_PORT, LCD_RW, LOGIC_LOW);
	_delay_ms(1);
	GPIO_writePin(LCD_POWER_PORT, LCD_ENABLE, LOGIC_HIGH);
	_delay_ms(1);
	GPIO_writePort(LCD_DATA_PORT, a_command);
	_delay_ms(1);
	GPIO_writePin(LCD_POWER_PORT, LCD_ENABLE, LOGIC_LOW);
	_delay_ms(1);
}

/*******************************************************************************
� Description
       -The Function is responsible to make RS pin to be 1 to display the wanted
       	character on the screen
� Inputs:
		-character: ASCII of the wanted character to be displayed
� Return: None
 *******************************************************************************/
void LCD_sendCharacter(const uint8 a_character){
	GPIO_writePin(LCD_POWER_PORT, LCD_RS, LOGIC_HIGH);
	GPIO_writePin(LCD_POWER_PORT, LCD_RW, LOGIC_LOW);
	_delay_ms(1);
	GPIO_writePin(LCD_POWER_PORT, LCD_ENABLE, LOGIC_HIGH);
	_delay_ms(1);
	GPIO_writePort(LCD_DATA_PORT, a_character);
	_delay_ms(1);
	GPIO_writePin(LCD_POWER_PORT, LCD_ENABLE, LOGIC_LOW);
	_delay_ms(1);
}

/*******************************************************************************
� Description
       -The Function is responsible to display string
� Inputs:
		-string: The string wanted to be displayed
� Return: None
 *******************************************************************************/
void LCD_sendString(const uint8 *a_string){
while((*a_string)!='\0'){
	LCD_sendCharacter(*a_string);
	a_string++;
}
}

/*******************************************************************************
� Description
       -Move the cursor to start writing on the correct place on the LCD screen
� Inputs:
		-row: Whether 1,2,3,4. If the connected LCD is 2 lines only the only
		  	  allowed numbers are 1 and 2;
		-col: Specify which column. From 0 -> 15
� Return: None
 *******************************************************************************/
void LCD_moveCursor(uint8 a_row,uint8 a_column){
	uint8 lcd_memory_address;
	if(a_column > 16){

	}
	else{
#if (LCD_ROWS==2)

		switch(a_row){
		case 1:
			lcd_memory_address=a_column;
			break;
		case 2:
			lcd_memory_address=a_column+0x40;
			break;
		}

#elif (LCD_ROWS==4)
		switch(a_row){
		case 1:
			lcd_memory_address=a_column;
			break;
		case 2:
			lcd_memory_address=a_column+0x40;
			break;
		case 3:
			lcd_memory_address=a_column+0x10;
			break;
		case 4:
			lcd_memory_address=a_column+0x50;
			break;
		}
#endif

		LCD_sendCommand(LCD_SET_CURSOR_LOCATION|lcd_memory_address);
	}
}

/*******************************************************************************
� Description
       -Write certain string in certain row and column
� Inputs:
		-row: Whether 0, 1, 2 or 3. If the connected LCD is 2 lines only the only
		  	  allowed numbers are 0 and 1;
		-col: Specify which column. From 0 -> 15
� Return: None
 *******************************************************************************/
void LCD_displayStringRowColumn(uint8 row,uint8 col,const uint8 *Str)
{
	LCD_moveCursor(row,col); /* go to to the required LCD position */
	LCD_sendString(Str); /* display the string */
}

/*******************************************************************************
� Description
       -This function expects an integer and displays it on screen
� Inputs:
		-integer: integer number
� Return: None
 *******************************************************************************/
void LCD_intgerToString(int data)
{
	uint8 buff[16]; /* String to hold the ascii result */
	itoa(data,buff,10); /* Use itoa C function to convert the data to its corresponding ASCII value, 10 for decimal */
	LCD_sendString(buff); /* Display the string */
}

/*******************************************************************************
� Description
       -This function sends command to the LCD to clear screen
� Inputs: None
� Return: None
 *******************************************************************************/
void LCD_clearScreen(void){
	LCD_sendCommand(CMD_CLEAR_DISPLAY);
}

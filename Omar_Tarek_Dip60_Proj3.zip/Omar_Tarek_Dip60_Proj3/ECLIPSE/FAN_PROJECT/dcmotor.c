 /******************************************************************************
 *
 * Module: DCMOTOR
 *
 * File Name: dcmotor.c
 *
 * Description: DC MOTOR DRIVER FOR AVR
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/


#include "pwm0.h"
#include "dcmotor.h"
#include "gpio.h"


/*
The Function responsible for setup the direction for the two
motor pins through the GPIO driver.

Stop at the DC-Motor at the beginning through the GPIO driver
 */
void DcMotor_init(void){
	GPIO_setupPinDirection(DCMOTOR_PORT, DCMOTOR_PIN1, PIN_OUTPUT);
	GPIO_setupPinDirection(DCMOTOR_PORT, DCMOTOR_PIN2, PIN_OUTPUT);
}

/*
 The function responsible for rotate the DC Motor CW/ or A-CW or
stop the motor based on the state input state value.

 Send the required duty cycle to the PWM driver based on the
required speed value.
 */
void DcMotor_Rotate(DcMotor_State state,uint8 speed){

	if (state==CLOCKWISE){
		GPIO_writePin(DCMOTOR_PORT, DCMOTOR_PIN1, LOGIC_LOW);
		GPIO_writePin(DCMOTOR_PORT, DCMOTOR_PIN2, LOGIC_HIGH);
	}
	else{
		GPIO_writePin(DCMOTOR_PORT, DCMOTOR_PIN1, LOGIC_LOW);
		GPIO_writePin(DCMOTOR_PORT, DCMOTOR_PIN2, LOGIC_HIGH);
	}
	speed=((float)(speed)/100)*255;
	PWM0_modifyOCR0(speed);

}

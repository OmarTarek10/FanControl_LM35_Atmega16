 /******************************************************************************
 *
 * Module: LM35
 *
 * File Name: lm35.c
 *
 * Description: Simple Driver for Temperature Sensor
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/

#include "lm35.h"

/*******************************************************************************
� Description
       -The Function is responsible for reading temperature using ADC driver
	   -Can Work with interrupts or polling
� Inputs: configuration STRUCT of ADC,ADC no
� Return: Temperature value
 *******************************************************************************/
#ifndef ADC_interruptEn
uint8 LM35_getTemp(ADC_ConfigType* lm35_config){
	uint8 temp;
	uint16 adcvalue;
#ifndef ADC_interruptEn
	adcvalue = ADC_readChannel(lm35_config->adcn);
#endif
#ifdef ADC_interruptEn
	ADC_readChannel(lm35_config->adcn);
#endif
	temp = (uint8)(((uint32)adcvalue*LM35_MAXTEMP*ADC_VREF)/(LM35_MAXVOLT*1023));
	return temp;
}
#else
uint8 LM35_getTemp(ADC_ConfigType* lm35_config){
	uint8 temp;

	ADC_readChannel(lm35_config->adcn);
	temp = (uint8)(((uint32)g_adcResult*LM35_MAXTEMP*ADC_VREF)/(LM35_MAXVOLT*1023));
	return temp;
}
#endif

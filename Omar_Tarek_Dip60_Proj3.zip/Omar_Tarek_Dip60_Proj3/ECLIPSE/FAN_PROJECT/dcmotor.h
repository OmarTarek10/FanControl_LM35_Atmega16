 /******************************************************************************
 *
 * Module: DCMOTOR
 *
 * File Name: dcmotor.h
 *
 * Description: DC MOTOR DRIVER FOR AVR
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/

#ifndef DCMOTOR_H_
#define DCMOTOR_H_

#include "std_types.h"
#define DCMOTOR_PIN1 PIN1_ID
#define DCMOTOR_PIN2 PIN0_ID
#define DCMOTOR_SPEED_PIN PIN3_ID
#define DCMOTOR_PORT PORTB_ID



/*
 * in order to detect which direction should motor rotate.
 */
typedef enum {
	CLOCKWISE=0,ANTI_CLOCKWISE=1
}DcMotor_State;

void DcMotor_init(void);
void DcMotor_Rotate(DcMotor_State state,uint8 speed);





#endif /* DCMOTOR_H_ */

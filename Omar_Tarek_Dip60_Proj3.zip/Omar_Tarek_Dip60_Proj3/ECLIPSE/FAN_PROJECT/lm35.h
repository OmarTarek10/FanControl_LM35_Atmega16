 /******************************************************************************
 *
 * Module: LM35
 *
 * File Name: lm35.h
 *
 * Description: Simple Driver for Temperature Sensor
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/
#ifndef LM35_H_
#define LM35_H_
#include "std_types.h"
#include "gpio.h"
#include "adc.h"

#define LM35_SIG_PIN PIN2_ID
#define LM35_SIG_PORT PORTB_ID
#define LM35_MAXTEMP 150
#define LM35_MAXVOLT 1.5
#define LM35_VOLT_RES 10

/*****************************************
 * 		FUNCTION PROTOTYPES				 *
 ****************************************/
uint8 LM35_getTemp(ADC_ConfigType* lm35_config);


#endif /* LM35_H_ */

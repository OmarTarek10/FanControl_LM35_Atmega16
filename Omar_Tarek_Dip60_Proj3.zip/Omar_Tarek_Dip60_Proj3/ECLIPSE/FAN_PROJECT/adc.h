 /******************************************************************************
 *
 * Module: ADC
 *
 * File Name: adc.h
 *
 * Description: Header file for ADC driver
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/
#ifndef ADC_H_
#define ADC_H_

#include "std_types.h"

extern volatile uint16 g_adcResult;

/*************************************************
 * 				Definitions						 *
 ************************************************/
#define ADC_MAXVALUE 1023
#define ADC_MINVALUE 0
#define ADC_VREF  5

#define ADC_START 6/*ADC START REGISTER NUMBER IN ADCSRA*/

/*#define ADC_interruptEn */ /*IF ENABLED DONT FORGET TO ADD #include"avr/inerrupt.h"*/
#define ADC_interruptF 4
#define ADC_interrupt_REG ADCSRA_REG
#define ADC_INTERRUPT_EN_BIT 3/*interrupt enable bit*/
/*************************************************
 * 				NEW_TYPES
 ************************************************/
typedef enum{
	ADC_div2 = 0x80,ADC_div4=0x82,ADC_div8= 0x83,ADC_div16=0x84,ADC_div32 = 0x85,ADC_div64=0x86,ADC_div128= 0x87
}ADC_divFactorEn;

typedef enum{
	ADC_free =0x00,ADC_analogComparator=0x21,ADC_extInt0=0x22,ADC_tim0C=0x23,ADC_tim0OV=0x24,ADC_tim1CB=0x25,ADC_tim1OV=0x26,ADC_capture=0x27
}ADC_autoTrig;

typedef enum {
	ADC_0=0x00,ADC_1=0x01,ADC_2=0x02,ADC_3=0x03,ADC_4=0x04,ADC_5=0x05,ADC_6=0x06,ADC_7=0x07
}ADC_num;

typedef enum{
	ADC_aref=0x00,ADC_vcc=0x40,ADC_internal=0xc0
}ADC_ref;


typedef struct{
	ADC_divFactorEn div;
	ADC_autoTrig mode;
	ADC_num adcn;
	ADC_ref adcref;
}ADC_ConfigType;

/*************************************************
 * 			FUNCTIONS PROTOTYPES                 *
 ************************************************/

void ADC_init(ADC_ConfigType *config);
void ADC_disable(void);
#ifdef ADC_interruptEn
void ADC_readChannel(uint8 a_channel_name);
#else
uint16 ADC_readChannel(uint8 a_channel_name);
#endif

#endif

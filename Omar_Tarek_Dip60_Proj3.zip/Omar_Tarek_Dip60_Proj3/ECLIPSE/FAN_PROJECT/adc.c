 /******************************************************************************
 *
 * Module: ADC
 *
 * File Name: adc.c
 *
 * Description: ADC driver
 *
 * Author: Omar Tarek
 *
 *******************************************************************************/

#include "adc.h"
#include "gpio.h"
#include "common_macros.h"
#include <avr/io.h>
#include <avr/interrupt.h>

#include "atmega_16_regs.h"
/*******************************************************************************
 *                          Global Variables                                   *
 *******************************************************************************/

volatile uint16 g_adcResult = 0;


#ifdef ADC_interruptEn
/*******************************************************************************
 *                          ISR's Definitions                                  *
 *******************************************************************************/
ISR(ADC_vect){

g_adcResult=ADC;

}
#endif


/*******************************************************************************
� Description
		-Adjust the reference voltage
		-Enable ADC
		-Adjust the prescaler value
� Inputs:
		- Config_Ptr: This is a pointer to structure containing the reference
					  voltage (AREF, AVCC or INTERNAL)
					  It also contains prescaler value (F_CPU_2, F_CPU_4, F_CPU_8,....)
� Return: None
 *******************************************************************************/
void ADC_init(ADC_ConfigType *config){
	ADMUX_REG=(config->adcref);

#ifndef ADC_interruptEn
	ADCSRA_REG = (config->div);
#else
	ADCSRA_REG = (config->div)|(1<<ADC_INTERRUPT_EN_BIT);
#endif
	SFIOR_REG=(config->mode);
}

/*=======================================================================*/

/****************************************************************************
� Description
		-Insert the ADC channel number (from 0 -> 7)
		-Start conversion
		-Wait until conversion is finished (pooling technique) (can be choosen as it can work either by interrupts or pooling)
� Inputs:
		- ch_num: Which ADC needed to be start converting
� Return:
		- returnValue: The analog converted to digital output (0 -> 1023)
 *******************************************************************************/

#ifdef ADC_interruptEn
void ADC_readChannel(uint8 a_channel_num){
	a_channel_num &= 0x07; /* Input channel number must be from 0 --> 7 */
	ADMUX_REG &= 0xE0; /* Clear first 5 bits in the ADMUX (channel number MUX4:0 bits) before set the required channel */
	ADMUX_REG = ADMUX_REG | a_channel_num;
	SET_BIT(ADCSRA_REG,ADC_START);
}
#else
uint16 ADC_readChannel(uint8 a_channel_num){
	a_channel_num &= 0x07; /* Input channel number must be from 0 --> 7 */
	ADMUX_REG &= 0xE0; /* Clear first 5 bits in the ADMUX (channel number MUX4:0 bits) before set the required channel */
	ADMUX_REG = ADMUX_REG | a_channel_num;
	SET_BIT(ADCSRA_REG,ADC_START);
	while(BIT_IS_CLEAR(ADC_interrupt_REG,ADC_interruptF));
	SET_BIT(ADCSRA_REG,ADC_interruptF); /* Clear ADIF by write '1' to it :) */
	return ADC_REG; /* Read the digital value from the data register */
}
#endif
/****************************************************************************
� Description
		-STOP ADC FROM WORKING AND RETURN EVERY REG TO INITIAL VALUE
� Inputs:
		- NONE
� Return:
		- returnValue:NONE
 *******************************************************************************/
void ADC_disable(void){
	ADMUX_REG=0;
	ADCSRA_REG=0;
	SFIOR_REG=0x0f;
}


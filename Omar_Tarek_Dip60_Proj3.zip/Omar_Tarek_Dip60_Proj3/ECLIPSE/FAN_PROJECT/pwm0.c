 /******************************************************************************
 *
 * Module: PWM
 *
 * File Name: pwm.c
 *
 * Description: PWM0 DRIVER THAT SUPPORTS ITS MODES
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/

#include "pwm0.h"

#include "atmega_16_regs.h"
#include "common_macros.h"
#include "gpio.h"


 /******************************************************************************
� Description:
- The function responsible for trigger the Timer0 with the non inverting PWM Mode
- Sets the prescaler with F_CPU/8.
- Sets the compare value based on the required input duty cycle
- For example: If the duty_cycle is 25, the compare value will be 0.25(255)
- Sets the direction for OC0 as output pin through the GPIO driver.
- The generated PWM signal frequency will be 500Hz to control the DC
  Motor speed.
� Inputs:
- duty_cycle: The required duty cycle percentage of the generated
  PWM signal. Its value is from 0 -> 100
� Return: None
 *******************************************************************************/

void PWM0_init(const PWM_Config *s_Configuration){
	GPIO_setupPinDirection(TIMER0_PWM_PORT, PWM0_PIN, PIN_OUTPUT);
	OCR0_REG=(s_Configuration->OCR0_value);
	TCCR0_REG=(s_Configuration->Prescaler)|(s_Configuration->mode);
	TCNT0_REG=0;
}

/********************************************************
 * DESCIPTION:
 * the function is responsible for changing the duty cycle
 * of the pwm signal.
 *
 -Inputs:
 	 Duty Cycle .
 *************************************/
void PWM0_modifyOCR0(const uint8 value){
	if (value <=0xff)
	OCR0_REG=value;
}

/*******************************************************
 * Description:
 * function that stops the PWM from opting.
 *
 * inputs:
 * 	NONE.
 **************************************/
void PWM0_Stop(void){
	TCCR0_REG=0;
}

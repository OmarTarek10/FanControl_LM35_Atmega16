 /******************************************************************************
 *
 * Module: PWM
 *
 * File Name: pwm.h
 *
 * Description: PWM0 DRIVER SUPPORTING ALL ITS MODES
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/

#include "std_types.h"

/*****************************************
 * 				DEFINES					 *
 ****************************************/
#define TIMER0_PWM_PORT PORTB_ID
#define PWM0_PIN PIN3_ID

/*********************************************
 * 				NEWTYPES					 *
 ********************************************/

typedef enum {
PWM_NONINVERTING0=0x60,PWM_INVERTING0=0x70
}TCCR0_WAVE_MODE;

typedef enum {
	TIMER0_PRE_0=0x00,TIMER0_PRE_1=0x01,TIMER0_PRE_8=0x02,
	TIMER0_PRE_64=0x03,TIMER0_PRE_256=0x04,TIMER0_PRE_1024=0x05
}TCCR0_PRESCALER;

typedef struct{
	TCCR0_WAVE_MODE mode;
	TCCR0_PRESCALER Prescaler;
	uint8 OCR0_value;
}PWM_Config;

/***************************************
 * 			FUNCTION PROTOTYPES				   *
 **************************************/
/******************************************************************************
� Description:
- The function responsible for trigger the Timer0 with the non inverting PWM Mode
- Sets the prescaler with F_CPU/8.
- Sets the compare value based on the required input duty cycle
- For example: If the duty_cycle is 25, the compare value will be 0.25(255)
- Sets the direction for OC0 as output pin through the GPIO driver.
- The generated PWM signal frequency will be 500Hz to control the DC
 Motor speed.
� Inputs:
- configuration structure of PWM
� Return: None
*******************************************************************************/
void PWM0_init(const PWM_Config *s_Configuration);

/********************************************************
 * DESCIPTION:
 * the function is responsible for changing the duty cycle
 * of the pwm signal.
 *
 -Inputs:
 	 Duty Cycle .
 *************************************/
void PWM0_modifyOCR0(const uint8 value);

/*******************************************************
 * Description:
 * function that stops the PWM from opting.
 *
 * inputs:
 * 	NONE.
 **************************************/
void PWM0_Stop(void);

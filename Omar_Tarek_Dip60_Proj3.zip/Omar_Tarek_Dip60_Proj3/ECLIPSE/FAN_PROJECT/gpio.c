 /******************************************************************************
 *
 * Module: GPIO
 *
 * File Name: gpio.h
 *
 * Description: GPIO driver for AVR
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/

#include "gpio.h"

#include "atmega_16_regs.h"
#include "common_macros.h"
/*======================================================================================*/
void GPIO_setupPinDirection(uint8 port_num,uint8 pin_num,GPIO_PinDirectionType direction){
	if((pin_num >= NUM_OF_PINS_PER_PORT) || (port_num >= NUM_OF_PORTS))
	{
		/* Do Nothing */
	}
	else{


		switch (port_num){
		case PORTA_ID:
			if(direction==PIN_OUTPUT){
				SET_BIT(DDRA_REG,pin_num);
			}
			else{
				CLEAR_BIT(DDRA_REG,pin_num);
			}
			break;
		case PORTB_ID:
			if(direction==PIN_OUTPUT){
				SET_BIT(DDRB_REG,pin_num);
			}
			else{
				CLEAR_BIT(DDRB_REG,pin_num);
			}
			break;
		case PORTC_ID:
			if(direction==PIN_OUTPUT){
				SET_BIT(DDRC_REG,pin_num);
			}
			else{
				CLEAR_BIT(DDRC_REG,pin_num);
			}
			break;
		case PORTD_ID:
			if(direction==PIN_OUTPUT){
				SET_BIT(DDRD_REG,pin_num);
			}
			else{
				CLEAR_BIT(DDRD_REG,pin_num);
			}
			break;
		}
	}
}
/*======================================================================================*/
void GPIO_setupPortDirection(uint8 port_num,GPIO_PinDirectionType direction){
	if(port_num>=NUM_OF_PORTS){

	}
	else
	{
		/* Setup the port direction as required */
		switch(port_num)
		{
		case PORTA_ID:
			DDRA_REG = direction;
			break;
		case PORTB_ID:
			DDRB_REG = direction;
			break;
		case PORTC_ID:
			DDRC_REG = direction;
			break;
		case PORTD_ID:
			DDRD_REG = direction;
			break;
		}
	}
}
/*======================================================================================*/
void GPIO_setupSpecPinDirection(uint8 port_num,uint8 pins,GPIO_PinDirectionType direction){

	if(port_num>=NUM_OF_PORTS || pins >0xff){

	}
	else{
		switch(port_num){
		case PORTA_ID:
			if(direction==PIN_OUTPUT){
				DDRA_REG= ~pins;
			}
			else{
				DDRA_REG = pins;
			}
			break;
		case PORTB_ID:
			if(direction==PIN_OUTPUT){
				DDRB_REG= ~pins;
			}
			else{
				DDRB_REG= pins;
			}
			break;
		case PORTC_ID:
			if(direction==PIN_OUTPUT){
				DDRC_REG= ~pins;
			}
			else{
				DDRC_REG= (pins);
			}
			break;
		case PORTD_ID:
			if(direction==PIN_OUTPUT){
				DDRD_REG= ~pins;
			}
			else{
				DDRD_REG =(pins);
			}
			break;
		}
	}

}
/*======================================================================================*/
void GPIO_writePin(uint8 port_num,uint8 pin_num,uint8 value){
	if((pin_num >= NUM_OF_PINS_PER_PORT) || (port_num >= NUM_OF_PORTS))
		{
			/* Do Nothing */
		}
		else{

			switch(port_num){
			case PORTA_ID:
				if(value==LOGIC_HIGH){
					SET_BIT(PORTA_REG,pin_num);
				}
				else{
					CLEAR_BIT(PORTA_REG,pin_num);
				}
				break;
			case PORTB_ID:
				if(value==LOGIC_HIGH){
					SET_BIT(PORTB_REG,pin_num);
				}
				else{
					CLEAR_BIT(PORTB_REG,pin_num);
				}
				break;
			case PORTC_ID:
				if(value==LOGIC_HIGH){
					SET_BIT(PORTC_REG,pin_num);
				}
				else{
					CLEAR_BIT(PORTC_REG,pin_num);
				}
				break;
			case PORTD_ID:
				if(value==LOGIC_HIGH){
					SET_BIT(PORTD_REG,pin_num);
				}
				else{
					CLEAR_BIT(PORTD_REG,pin_num);
				}
				break;


			}
		}
}
/*=============================================================================*/
void GPIO_writeSpecPin(uint8 port_num,uint8 value){
	if(port_num>=NUM_OF_PORTS){

	}
	else{
		switch(port_num){
		case PORTA_ID:
			PORTA_REG=value;
			break;
		case PORTB_ID:
		PORTB_REG=value;
			break;
		case PORTC_ID:
			PORTC_REG=value;
			break;
		case PORTD_ID:
			PORTD_REG=value;
			break;
		}
	}
}
/*===============================================================================*/
void GPIO_writePort(uint8 port_num,GPIO_PortOutputValue value){
	if(port_num>=NUM_OF_PORTS){

	}
	else{
		switch (port_num){
		case PORTA_ID:
			PORTA_REG=value;
			break;
		case PORTB_ID:
			PORTB_REG=value;
			break;
		case PORTC_ID:
			PORTC_REG=value;
			break;
		case PORTD_ID:
			PORTD_REG=value;
			break;
			}
		}
	}
/*=======================================================================================*/
uint8 GPIO_readPin(uint8 port_num,uint8 pin_num){
	uint8 value;
	if(port_num>=NUM_OF_PORTS){
		return LOGIC_LOW;
	}
	else{
		switch (port_num){
		case PORTA_ID:
			if(BIT_IS_SET(PINA_REG,pin_num))
				value = LOGIC_HIGH;
			else
				value=LOGIC_LOW;
			break;
		case PORTB_ID:
			if(BIT_IS_SET(PINB_REG,pin_num))
				value = LOGIC_HIGH;
			else
				value=LOGIC_LOW;
			break;
		case PORTC_ID:
			if(BIT_IS_SET(PINC_REG,pin_num))
				value = LOGIC_HIGH;
			else
				value=LOGIC_LOW;
			break;
		case PORTD_ID:
			if(BIT_IS_SET(PIND_REG,pin_num))
				value = LOGIC_HIGH;
			else
				value=LOGIC_LOW;
			break;
		}
	}
	return value;
}
/*======================================================================*/
uint8 GPIO_readPort(uint8 port_num){
	uint8 value;
	if(port_num>=NUM_OF_PORTS){
		return LOGIC_LOW;
	}
	else{
		switch (port_num){
		case PORTA_ID:
			value=PINA_REG;
			break;
		case PORTB_ID:
			value=PINB_REG;
			break;
		case PORTC_ID:
			value=PINC_REG;
			break;
		case PORTD_ID:
			value=PIND_REG;
			break;
		}
	}
	return value;

}

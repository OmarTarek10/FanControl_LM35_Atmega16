 /******************************************************************************
 *
 * Module: FAN_PROJECT
 *
 * File Name: program.c
 *
 * Description: Main application layer
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/
#include "lm35.h" /*to include lm35 functions and definitions*/
#include "gpio.h" /*to include gpio functions and definitions*/
#include "lcd.h" /*to include lcd functions and definitions */
#include "std_types.h"
#include "pwm0.h" /*to include PWM0 functions and definitions*/
#include "dcmotor.h" /*to include DC motor functions and definitions*/

int main(void){
	PWM_Config s_Configuration ={PWM_NONINVERTING0,TIMER0_PRE_8,0};
	ADC_ConfigType lm35_config={ADC_div8,ADC_free,ADC_2,ADC_vcc};
	uint8 status;
	uint8 temp;
	DcMotor_init();
	ADC_init(&lm35_config);
	LCD_init();
	PWM0_init(&s_Configuration);
	LCD_moveCursor(1, 3);
	LCD_sendString((uint8 *)"FAN IS ");

while(1){
	LCD_moveCursor(1, 10);
	temp=LM35_getTemp(&lm35_config);
	if(temp<30){
		DcMotor_Rotate(CLOCKWISE, 0);
	status=0;
	}
	else if ((temp >=30) && (temp<60)){
		DcMotor_Rotate(CLOCKWISE, 25);
		status =1;
	}
	else if ((temp >=60) && (temp<90)){
			DcMotor_Rotate(CLOCKWISE, 50);
	status=1;
	}
	else if ((temp >=90) && (temp<120)){
				DcMotor_Rotate(CLOCKWISE, 75);
	status=1;
	}
	else{
		DcMotor_Rotate(CLOCKWISE, 100);
		status=1;
	}

	if(status==0){
		LCD_sendString((uint8 *)"OFF");
	}
	else{
		LCD_sendString((uint8 *)"ON ");
	}

	LCD_moveCursor(2, 4);
	LCD_sendString((uint8 *)"Temp =");

	if(temp>100){
	LCD_intgerToString(temp);
	}
	else{
		LCD_intgerToString(temp);
		LCD_sendCharacter(' ');
	}
}

	return 0;
}
